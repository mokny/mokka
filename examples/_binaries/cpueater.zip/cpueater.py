while True:
    pass